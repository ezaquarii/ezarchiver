from .folder_parser import parse_sync_folder
from .sync import sync_folders

assert parse_sync_folder
assert sync_folders
